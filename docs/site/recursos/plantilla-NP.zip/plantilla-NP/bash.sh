docker container exec -it php  bash
